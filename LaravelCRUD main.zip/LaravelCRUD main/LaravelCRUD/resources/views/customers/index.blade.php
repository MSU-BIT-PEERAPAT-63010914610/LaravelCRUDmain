<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel CRUD Index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Laravel 8 CRUD</h2>
            </div>
            <div>
                <a href="{{ route('customers.create') }}" class="btn btn-success">Create Customer</a>
            </div>
            @if ($message = session()->get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
            @endif

            <table class="table table-bordered">
                <tr>
                    <th>Customer Name</th>
                    <th>Customer Tel</th>
                    <th>Customer Address</th>
                    <th width="280px">Action</th>
                </tr>
                @foreach($customers as $customer)
                <tr>
                    <td>{{ $customer->cust_name }}</td>
                    <td>{{ $customer->cust_tel }}</td>
                    <td>{{ $customer->cust_add }}</td>
                    <td>
                        <!-- เพิ่มปุ่มหรือลิงก์สำหรับการดำเนินการต่าง ๆ ตามที่คุณต้องการ -->
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
    </div>
</body>
</html>
