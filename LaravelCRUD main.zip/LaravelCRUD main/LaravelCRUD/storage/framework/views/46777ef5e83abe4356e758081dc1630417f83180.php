<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel CRUD index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Laravel 8 CRUD Example</h2>
            </div>
            <div>
                <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-success">Create Company</a>
            </div>
        </div>
    </div>


</body>
</html><?php /**PATH C:\Users\HomeLess\Desktop\LaravelCRUD\resources\views/companies/index.blade.php ENDPATH**/ ?>