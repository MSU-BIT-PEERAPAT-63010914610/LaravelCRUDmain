<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel CRUD Index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Laravel 8 CRUD</h2>
            </div>
            <div>
                <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success">Create Customer</a>
            </div>
            <?php if($message = session()->get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <table class="table table-bordered">
                <tr>
                    <th>Customer Name</th>
                    <th>Customer Tel</th>
                    <th>Customer Address</th>
                    <th width="280px">Action</th>
                </tr>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer->cust_name); ?></td>
                    <td><?php echo e($customer->cust_tel); ?></td>
                    <td><?php echo e($customer->cust_add); ?></td>
                    <td>
                        <!-- เพิ่มปุ่มหรือลิงก์สำหรับการดำเนินการต่าง ๆ ตามที่คุณต้องการ -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\HomeLess\Desktop\LaravelCRUD\resources\views/customers/index.blade.php ENDPATH**/ ?>