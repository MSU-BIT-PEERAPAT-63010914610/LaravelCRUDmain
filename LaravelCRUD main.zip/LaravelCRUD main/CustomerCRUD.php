<?php

namespace App\Http\Controllers;

use App\Models\Customer; // Fixed typo in 'use' statement
use Illuminate\Http\Request;

class CustomerCRUDController extends Controller // Corrected the class name
{
    public function index()
    {
        $data['customers'] = Customer::orderBy('id', 'desc')->paginate(5);
        return view('customers.index', $data);
    }

    public function create()
    {
        return view('customers.create'); // Fixed typo in 'view' function
    }

    public function store(Request $request)
{
    $request->validate([
        'cust_name' => 'required',
        'cust_tel' => 'required',
        'cust_add' => 'required',
    ]);

    $customer = new Customer; // Fixed missing semicolon
    $customer->cust_name = $request->cust_name;
    $customer->cust_tel = $request->cust_tel;
    $customer->cust_add = $request->cust_add;
    $customer->save();

    return redirect()->route('customers.index')->with('success', 'Customer has been created successfully');
}

}
